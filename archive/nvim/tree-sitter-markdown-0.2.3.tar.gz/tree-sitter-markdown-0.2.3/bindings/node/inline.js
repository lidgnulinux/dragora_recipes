module.exports = require(".").inline;
