# wlr-protocols

Wayland protocols designed for use in wlroots (and other compositors).

## Submitting changes to existing protocols

Please submit a merge request on GitLab.

## Submitting new protocols

New protocols should not be submitted to wlr-protocols. Instead, submit them to
[wayland-protocols].

[wayland-protocols]: https://gitlab.freedesktop.org/wayland/wayland-protocols
